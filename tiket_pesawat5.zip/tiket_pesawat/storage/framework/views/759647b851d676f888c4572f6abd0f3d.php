<?php $__env->startSection('title'); ?>
    About
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            Ini adalah halaman about
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\AXIOO DKV 06\Documents\GitHub\tiketpesawat\tiket_pesawat\resources\views\tentang\about.blade.php ENDPATH**/ ?>