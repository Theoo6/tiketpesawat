@extends('master.layout')

@section('title')
    About
@endsection

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            Ini adalah halaman about
        </div>
    </div>
</div>
@endsection
